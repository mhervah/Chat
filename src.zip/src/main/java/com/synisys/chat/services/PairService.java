package com.synisys.chat.services;

import com.synisys.chat.models.Pair;

/**
 * Created by mher.vahramyan on 11/5/2018.
 */
public class PairService {

    public static PairService pairService = new PairService();

    private PairService(){

    }

}
