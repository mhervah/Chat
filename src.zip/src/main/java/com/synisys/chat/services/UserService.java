package com.synisys.chat.services;

import com.synisys.chat.dao.UserDao;
import com.synisys.chat.models.Chat;
import com.synisys.chat.models.User;

import javax.jws.soap.SOAPBinding;
import java.util.ArrayList;

public class UserService {
    public static  UserService userService = new UserService();

    private UserService(){

    }
    private static int index = 0;
    public void deleteUsers(ArrayList<String> list){
       for(int i=0;i<list.size();i++){
            removeUser(Integer.parseInt(list.get(i)));
        }

    }
    private void removeUser(int id){
        for (User user:UserDao.users) {
            if(user.getId()==id){
                UserDao.users.remove(user);
                break;
            }
        }
    }
    public boolean checkUser(User loginUser) {
        for (User user : UserDao.users) {
            if (user.getPassword().equals(loginUser.getPassword()) && user.getUsername().equals(loginUser.getUsername())) {
                return true;
            }
        }
        return false;
    }

    public boolean checkUsername(User loginUser) {
        for (User user : UserDao.users) {
            if (user.getUsername().equals(loginUser.getUsername())) {
                return true;
            }
        }
        return false;
    }

    public boolean checkUsername(String registerUsername){
        for (User user : UserDao.users) {
            if (user.getUsername().equals(registerUsername)) {
                return true;
            }
        }
        return false;
    }

    public boolean checkAdmin(User loginUser) {
        return UserDao.getAdmin().getUsername().equals(loginUser.getUsername()) && UserDao.getAdmin().getPassword().equals(loginUser.getPassword());
    }

    public void addUser(String username, String password) {
        User newUser = new User(username, password,index++);
        UserDao.users.add(newUser);
        for (User user: UserDao.users) {

            user.addChat(new Chat(user ,newUser));
        }
    }
}
