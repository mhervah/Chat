package com.synisys.chat.services;

import com.synisys.chat.models.Chat;
import com.synisys.chat.models.Message;

/**
 * Created by mher.vahramyan on 11/1/2018.
 */
public class ChatService {
    void addMessage(Chat chat, Message message){
        chat.addMessage(message);
    }
}
