package com.synisys.chat;

import com.synisys.chat.Constant;

import java.util.ArrayList;
import java.util.List;

public class UserDao {
    public static List<User> users;

    public static User getAdmin(){
        for (User user:users) {
            if(user.getId()== Constant.ADMIN_ID)
                return user;
        }
        return null;
    }
    static {
        users = new ArrayList<>();
        users.add(new User("Mher", "pass", Constant.ADMIN_ID));
    }
}
