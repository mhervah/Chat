package com.synisys.chat.constants;

/**
 * Created by mher.vahramyan on 10/12/2018.
 */
public class Constants {
    public static  int ADMIN_ID=-1;
}
