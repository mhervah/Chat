package com.synisys.chat.servlets;

import com.google.gson.Gson;
import com.synisys.chat.models.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;

import static com.synisys.chat.services.UserService.userService;

public class ValidationServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        Gson gson = new Gson();
        User user = gson.fromJson(req.getReader(), User.class);
        String username = user.getUsername();
        String password = user.getPassword();
        User userObj = new User(username, password);

        if(userService.checkUser(userObj)){
            resp.setHeader("validation","full");
        }else if(userService.checkUsername(userObj)){
            resp.setHeader("validation","part");
        }
        else{
            resp.setHeader("validation","no");
        }
    }
}
