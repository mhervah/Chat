package com.synisys.chat;

public class Service {
    public void addMessage(Message message){
        MessageDao.messages.add(message);
    }
}
