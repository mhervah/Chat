package com.synisys.chat.exceptions;

/**
 * Created by mher.vahramyan on 11/6/2018.
 */
public class UserNotFoundException extends RuntimeException {

}
