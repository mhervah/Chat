package com.synisys.chat;

import java.util.ArrayList;

public class MessageDao {
    public static ArrayList<Message> messages = new ArrayList<>();
}
