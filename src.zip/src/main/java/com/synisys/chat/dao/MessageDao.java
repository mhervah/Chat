package com.synisys.chat.dao;

import com.synisys.chat.models.Message;

import java.util.ArrayList;

public class MessageDao {
    public static ArrayList<Message> messages = new ArrayList<>();
}
