var messageText = document.getElementById("message").value;
var message ={
  "sender" :
};
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {

    }
};
xhttp.open("post", "send", true);
xhttp.send(messageText);